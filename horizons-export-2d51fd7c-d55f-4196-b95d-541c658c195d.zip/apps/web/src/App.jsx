import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { ThemeProvider } from 'next-themes';
import ScrollToTop from './components/ScrollToTop';
import { PlannerProvider } from './state/PlannerContext';
import HomePage from './pages/HomePage';
import PlannerPage from './pages/PlannerPage';
import AboutPage from './pages/AboutPage';

function App() {
    return (
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
            <PlannerProvider>
                <Router>
                    <ScrollToTop />
                    <Routes>
                        <Route path="/" element={<HomePage />} />
                        <Route path="/planner" element={<PlannerPage />} />
                        <Route path="/about" element={<AboutPage />} />
                    </Routes>
                </Router>
            </PlannerProvider>
        </ThemeProvider>
    );
}

export default App;
