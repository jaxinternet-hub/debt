import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams } from 'react-router-dom';
import { Save, Trash2, Upload } from 'lucide-react';
import { Header, Footer } from '@/components/site/Shell';
import UploadStage from '@/components/planner/UploadStage';
import Dashboard from '@/components/planner/Dashboard';
import DebtPlan from '@/components/planner/DebtPlan';
import Wealth from '@/components/planner/Wealth';
import Coach from '@/components/planner/Coach';
import { usePlanner } from '@/state/PlannerContext';
import { demoTransactions } from '@/lib/finance';

const TABS = [
    { id: 'overview', label: 'Overview' },
    { id: 'debt', label: 'Eliminate debt' },
    { id: 'wealth', label: 'Build wealth' },
    { id: 'coach', label: 'Coach & reports' },
];

export default function PlannerPage() {
    const { hasData, loadTransactions, sourceLabel, saveSession, clearEverything, savedAt } = usePlanner();
    const [params] = useSearchParams();
    const [tab, setTab] = useState('overview');

    useEffect(() => {
        if (params.get('demo') === '1' && !hasData) {
            loadTransactions(demoTransactions(4), 'Sample household statement');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [params]);

    return (
        <div className="min-h-screen bg-background text-foreground">
            <Helmet>
                <title>Planner — Financial Freedom Planner AI</title>
                <meta name="description" content="Upload a statement to see your categorised budget, detected debts, snowball or avalanche payoff simulator, savings projections, health score and budget optimiser." />
            </Helmet>
            <Header />

            {!hasData ? <UploadStage /> : (
                <main className="mx-auto w-full max-w-[80rem] px-5 pb-8 pt-8 sm:px-8">
                    <div className="flex flex-wrap items-center gap-3 rounded-3xl border border-border bg-card px-5 py-4">
                        <div className="min-w-0">
                            <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Analysing</p>
                            <p className="truncate font-display text-base font-semibold">{sourceLabel || 'Your statement'}</p>
                        </div>
                        <div className="ml-auto flex flex-wrap gap-2">
                            <button type="button" onClick={saveSession} className="inline-flex min-h-[2.75rem] items-center gap-2 rounded-full border border-border px-4 text-sm font-medium active:scale-[0.98]">
                                <Save className="h-4 w-4" strokeWidth={1.7} /> {savedAt ? 'Saved' : 'Save to this device'}
                            </button>
                            <button type="button" onClick={clearEverything} className="inline-flex min-h-[2.75rem] items-center gap-2 rounded-full border border-border px-4 text-sm font-medium text-destructive active:scale-[0.98]">
                                <Trash2 className="h-4 w-4" strokeWidth={1.7} /> Clear data
                            </button>
                            <button type="button" onClick={() => { clearEverything(); }} className="inline-flex min-h-[2.75rem] items-center gap-2 rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground active:scale-[0.98]">
                                <Upload className="h-4 w-4" strokeWidth={1.8} /> New statement
                            </button>
                        </div>
                    </div>

                    <nav aria-label="Planner sections" className="sticky top-[4.5rem] z-30 -mx-5 mt-5 overflow-x-auto bg-background/90 px-5 py-3 backdrop-blur sm:-mx-8 sm:px-8">
                        <div className="inline-flex gap-1 rounded-full border border-border bg-card p-1">
                            {TABS.map((t) => (
                                <button
                                    key={t.id}
                                    type="button"
                                    onClick={() => setTab(t.id)}
                                    aria-current={tab === t.id ? 'page' : undefined}
                                    className={`whitespace-nowrap rounded-full px-4 py-2.5 text-sm font-medium transition-colors ${tab === t.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
                                >
                                    {t.label}
                                </button>
                            ))}
                        </div>
                    </nav>

                    <div className="mt-8">
                        {tab === 'overview' && <Dashboard />}
                        {tab === 'debt' && <DebtPlan />}
                        {tab === 'wealth' && <Wealth />}
                        {tab === 'coach' && <Coach />}
                    </div>

                    <p className="mt-12 rounded-2xl border border-border bg-secondary/50 p-5 text-xs leading-relaxed text-muted-foreground">
                        Educational tool, not financial advice. Balances, interest rates and projections are estimates. Your
                        data stays in this browser tab and is discarded on refresh unless you press save.
                    </p>
                </main>
            )}

            <Footer />
        </div>
    );
}
