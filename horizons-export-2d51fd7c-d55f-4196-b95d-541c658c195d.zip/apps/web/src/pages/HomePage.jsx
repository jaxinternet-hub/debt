import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, FileText, Camera, Table2, Landmark, ShieldCheck, TrendingUp, Sparkles } from 'lucide-react';
import Reveal from '@/components/Reveal';
import CountUp from '@/components/CountUp';
import Seo from '@/components/Seo';
import { Header, Footer } from '@/components/site/Shell';

const HERO_IMAGE = 'https://images.hostinger.com/f7d6609c-896b-421e-9733-62ef9461119a.png';

const ticker = [
    'Capital One', 'Barclaycard', 'Klarna', 'Car finance', 'Tesco Bank', 'PayPal Credit',
    'Store cards', 'Overdraft', 'Student loan', 'Personal loans', 'Very', 'Next',
];

const stages = [
    {
        tag: 'Stage one',
        title: 'Eliminate debt',
        body: 'Every credit agreement in your statement is found, priced and ranked. Choose snowball or avalanche, then watch each cleared payment roll into the next debt like dominoes falling.',
        icon: TrendingUp,
    },
    {
        tag: 'Stage two',
        title: 'Build wealth',
        body: 'The moment the last debt clears, every pound that used to service it is redirected into savings — projected out over 6 months to 20 years with adjustable growth assumptions.',
        icon: Sparkles,
    },
];

export default function HomePage() {
    return (
        <div className="min-h-screen bg-background text-foreground">
            <Helmet>
                <title>Financial Freedom Planner AI — Understand Your Money, Eliminate Debt, Build Wealth</title>
                <meta name="description" content="Upload a bank statement and get an instant spending breakdown, debt payoff plan, savings projection and financial health score. Runs entirely in your browser — no login, no banking access." />
            </Helmet>
            <Seo
                title="Financial Freedom Planner AI"
                description="Understand your money, eliminate debt, build wealth. A private, browser-based budgeting and debt payoff planner."
                image={HERO_IMAGE}
                siteName="Financial Freedom Planner AI"
            />
            <Header />

            {/* Hero: split copy + media, calm and optimistic */}
            <section className="relative overflow-hidden">
                <div className="pointer-events-none absolute -right-24 -top-32 h-[26rem] w-[26rem] rounded-full bg-accent/70 blur-3xl" aria-hidden="true" />
                <div className="mx-auto grid w-full max-w-[80rem] items-center gap-12 px-5 pb-16 pt-14 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24 lg:pt-20">
                    <div>
                        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium tracking-wide text-muted-foreground">
                            <ShieldCheck className="h-4 w-4 text-primary" strokeWidth={1.8} />
                            No login. No banking access. Nothing leaves your device.
                        </span>
                        <h1 className="mt-6 font-display text-[2.6rem] font-semibold leading-[1.03] tracking-[-0.02em] sm:text-6xl lg:text-[4.1rem]">
                            Understand your money.
                            <span className="relative mx-1 inline-block">
                                <span className="relative z-10">Eliminate debt.</span>
                                <motion.span
                                    aria-hidden="true"
                                    initial={{ scaleX: 0 }}
                                    animate={{ scaleX: 1 }}
                                    transition={{ delay: 0.5, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                                    className="absolute inset-x-[-2px] bottom-1 z-0 h-[0.42em] origin-left -rotate-1 rounded-[40%] bg-[hsl(var(--accent2))]/45"
                                />
                            </span>
                            <br className="hidden sm:block" />
                            Build wealth.
                        </h1>
                        <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground">
                            Drop in a statement — PDF, CSV, spreadsheet, Open Banking export, or even a photo of a printed
                            page. In seconds you get a categorised budget, a debt elimination plan that actually finishes,
                            and a savings forecast for the years after.
                        </p>
                        <div className="mt-8 flex flex-wrap items-center gap-3">
                            <Link
                                to="/planner"
                                className="group inline-flex h-14 items-center gap-2 rounded-full bg-primary px-7 text-base font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
                            >
                                Analyse my statement
                                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" strokeWidth={2} />
                            </Link>
                            <Link
                                to="/planner?demo=1"
                                className="inline-flex h-14 items-center rounded-full border border-border bg-card px-6 text-base font-medium transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
                            >
                                Explore with sample data
                            </Link>
                        </div>
                        <dl className="mt-10 grid max-w-lg grid-cols-3 gap-6 border-t border-border pt-6">
                            <div>
                                <dt className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Categories</dt>
                                <dd className="tabular font-display text-2xl font-semibold"><CountUp value={17} /></dd>
                            </div>
                            <div>
                                <dt className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Projection years</dt>
                                <dd className="tabular font-display text-2xl font-semibold"><CountUp value={20} /></dd>
                            </div>
                            <div>
                                <dt className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Data uploaded</dt>
                                <dd className="font-display text-2xl font-semibold">None</dd>
                            </div>
                        </dl>
                    </div>

                    <Reveal y={28}>
                        <div className="relative">
                            <div className="overflow-hidden rounded-[2rem] border border-border bg-card shadow-[0_30px_60px_-30px_hsl(195_40%_20%/0.35)]">
                                <img
                                    src={HERO_IMAGE}
                                    alt="A laptop on a kitchen table showing colourful spending charts beside a paper bank statement"
                                    className="h-[22rem] w-full object-cover sm:h-[28rem]"
                                    loading="eager"
                                />
                            </div>
                            <motion.div
                                initial={{ opacity: 0, y: 16 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: 0.8, duration: 0.5, ease: 'easeOut' }}
                                className="absolute -bottom-6 left-4 rounded-2xl border border-border bg-card px-5 py-4 shadow-lg sm:left-8"
                            >
                                <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Debt free by</p>
                                <p className="font-display text-xl font-semibold">March 2029</p>
                                <p className="mt-1 text-xs text-[hsl(var(--positive))]">£4,180 interest avoided</p>
                            </motion.div>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* Moving strip of recognised lenders */}
            <section aria-label="Recognised credit providers" className="border-y border-border bg-secondary/60 py-4">
                <div className="flex overflow-hidden">
                    <div className="animate-marquee flex shrink-0 items-center gap-8 whitespace-nowrap pr-8 text-sm uppercase tracking-[0.18em] text-muted-foreground">
                        {[...ticker, ...ticker].map((t, i) => (
                            <span key={`${t}-${i}`} className="flex items-center gap-8">
                                {t}
                                <span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--accent2))]" aria-hidden="true" />
                            </span>
                        ))}
                    </div>
                </div>
            </section>

            {/* Two stages — zig-zag, not cards */}
            <section className="mx-auto w-full max-w-[72rem] px-5 py-20 sm:px-8">
                <Reveal>
                    <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">The plan</p>
                    <h2 className="mt-3 max-w-2xl font-display text-3xl font-semibold leading-tight sm:text-4xl">
                        Two stages. One momentum curve.
                    </h2>
                </Reveal>
                <div className="mt-12 space-y-14">
                    {stages.map((s, i) => (
                        <Reveal key={s.title} delay={i * 0.08}>
                            <div className={`grid items-center gap-8 md:grid-cols-2 ${i % 2 ? 'md:[&>*:first-child]:order-2' : ''}`}>
                                <div>
                                    <span className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-accent-foreground">
                                        {s.tag}
                                    </span>
                                    <h3 className="mt-4 font-display text-2xl font-semibold sm:text-3xl">{s.title}</h3>
                                    <p className="mt-3 text-base leading-relaxed text-muted-foreground">{s.body}</p>
                                </div>
                                <div className="relative rounded-3xl border border-border bg-card p-7">
                                    <s.icon className="h-8 w-8 text-primary" strokeWidth={1.6} />
                                    <div className="mt-6 space-y-3">
                                        {(i === 0
                                            ? [['Capital One', 62], ['Klarna', 24], ['Car finance', 100], ['Tesco Bank loan', 78]]
                                            : [['6 months', 18], ['1 year', 36], ['5 years', 68], ['20 years', 100]]
                                        ).map(([label, pct], k) => (
                                            <div key={label}>
                                                <div className="flex justify-between text-sm">
                                                    <span>{label}</span>
                                                    <span className="tabular text-muted-foreground">{pct}%</span>
                                                </div>
                                                <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-secondary">
                                                    <motion.div
                                                        className={i === 0 ? 'h-full rounded-full bg-[hsl(var(--accent2))]' : 'h-full rounded-full bg-primary'}
                                                        initial={{ width: 0 }}
                                                        whileInView={{ width: `${pct}%` }}
                                                        viewport={{ once: true }}
                                                        transition={{ duration: 0.7, delay: k * 0.08, ease: 'easeOut' }}
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </Reveal>
                    ))}
                </div>
            </section>

            {/* Input formats — service menu board style */}
            <section className="border-y border-border bg-secondary/40 py-16">
                <div className="mx-auto w-full max-w-[72rem] px-5 sm:px-8">
                    <Reveal>
                        <h2 className="font-display text-3xl font-semibold sm:text-4xl">Bring whatever you have.</h2>
                        <p className="mt-3 max-w-2xl text-muted-foreground">
                            Transaction descriptions, dates and amounts are all the analysis needs. Balance columns are ignored.
                        </p>
                    </Reveal>
                    <ul className="mt-10 divide-y divide-border border-y border-border">
                        {[
                            [FileText, 'PDF statements', 'Text-layer PDFs are read directly; scanned pages fall back to built-in OCR.'],
                            [Table2, 'CSV & Excel exports', 'Standard bank exports, plus tab and semicolon separated files.'],
                            [Landmark, 'Open Banking JSON', 'Paste or upload an authorised data export — no credentials involved.'],
                            [Camera, 'Photos & screenshots', 'A phone photo of a printed statement is run through OCR in your browser.'],
                        ].map(([Icon, title, body], i) => (
                            <li key={title}>
                                <Reveal delay={i * 0.05}>
                                    <div className="flex flex-col gap-2 py-6 md:flex-row md:items-center md:gap-8">
                                        <Icon className="h-6 w-6 shrink-0 text-primary" strokeWidth={1.6} />
                                        <span className="font-display text-lg font-semibold md:w-64">{title}</span>
                                        <span className="text-sm text-muted-foreground md:flex-1">{body}</span>
                                    </div>
                                </Reveal>
                            </li>
                        ))}
                    </ul>
                </div>
            </section>

            {/* Closing CTA */}
            <section className="mx-auto w-full max-w-[56rem] px-5 py-24 text-center sm:px-8">
                <Reveal>
                    <h2 className="font-display text-3xl font-semibold leading-tight sm:text-5xl">
                        Your first honest month starts in about two minutes.
                    </h2>
                    <p className="mx-auto mt-5 max-w-xl text-muted-foreground">
                        No shame, no lectures. Just a clear picture, a finishable plan, and a forecast worth looking forward to.
                    </p>
                    <Link
                        to="/planner"
                        className="mt-9 inline-flex h-14 items-center gap-2 rounded-full bg-primary px-8 text-base font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
                    >
                        Open the planner
                        <ArrowRight className="h-5 w-5" strokeWidth={2} />
                    </Link>
                </Reveal>
            </section>

            <Footer />
        </div>
    );
}
