import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Reveal from '@/components/Reveal';
import { Header, Footer } from '@/components/site/Shell';

const sections = [
    {
        id: 'stage-one',
        heading: 'Stage One — Eliminate Debt',
        paras: [
            'Financial Freedom Planner AI begins by reading your statement and separating what you earn from what you spend. Every transaction is grouped into plain categories — housing, food, transport, debt, savings and so on — so that the first thing you see is the truth rather than a guess.',
            'Credit agreements are then singled out: credit cards, store cards, personal loans, car finance, buy-now-pay-later plans, overdrafts and student loans. For each one we estimate a balance and an interest rate from the size and rhythm of the payments, and you can correct any figure to match your paperwork.',
            'You then choose how to attack them. The snowball method clears the smallest balance first, which produces early wins and keeps motivation high. The avalanche method targets the highest interest rate first, which usually costs the least overall. Whichever you pick, the crucial mechanic is the same: when a debt is cleared, the money that used to service it is not absorbed back into everyday spending — it rolls into the next debt on the list. Each cleared debt makes the next one fall faster, like dominoes.',
        ],
    },
    {
        id: 'stage-two',
        heading: 'Stage Two — Build Wealth',
        paras: [
            'The day the last debt clears, you have a substantial monthly sum with no job to do. Most people quietly absorb it. This is the moment the planner is built for.',
            'Every former debt payment is redirected into savings and investments, and projected forward over six months, one year, three years, five years, ten years and twenty years. You control the assumed annual growth rate, and the chart always shows your contributions alongside the compounded total so you can see exactly how much is your money and how much is growth.',
        ],
    },
    {
        id: 'optimisation',
        heading: 'Budget Optimisation',
        paras: [
            'Alongside the plan, the app looks for money leaving quietly: overlapping streaming services, an insurance premium that has crept up at renewal, out-of-contract broadband, duplicated services, forgotten low-value subscriptions, and the small daily spends that add up without ever feeling like a decision.',
            'Suggestions are always framed as achievable adjustments with an estimated monthly saving attached. There is no shaming and no lecturing. Spending money on things you enjoy is not a moral failing — the goal is simply to make sure you chose it.',
        ],
    },
    {
        id: 'privacy',
        heading: 'Privacy',
        paras: [
            'The analysis runs entirely in your browser. Statements are parsed, read with OCR where needed, categorised and modelled on your own device. Nothing is uploaded to a server, and nothing is stored anywhere unless you explicitly press save — which writes to this browser only and can be cleared with one button.',
            'We never require login credentials and we never ask for online banking access. Before you upload anything, we recommend masking account numbers, sort codes, addresses, customer IDs, statement references, QR codes, barcodes and personal notes. The analysis only needs transaction descriptions, dates and amounts. The site is served over HTTPS and designed to be GDPR conscious by keeping personal data out of the loop entirely.',
        ],
    },
    {
        id: 'disclaimer',
        heading: 'Important Disclaimer',
        paras: [
            'Financial Freedom Planner AI is an educational tool. It does not provide regulated financial, debt, investment or tax advice, and it is not a substitute for speaking to a qualified adviser or a free debt charity if you are struggling.',
            'Balances, interest rates, payoff dates and savings projections are estimates produced from limited information and simplified assumptions. Real interest, charges, tax and market returns will differ. Always check figures against your own statements and agreements before making a decision.',
        ],
    },
];

const roadmap = [
    'Secure, user-authorised Open Banking connections',
    'AI-assisted bill negotiation',
    'Credit score tracking',
    'Mortgage and loan payoff calculators',
    'Household budgeting for couples and families',
    'Shared budgets and collaborative planning',
    'Investment portfolio tracking',
    'Pension forecasting',
    'Tax estimation tools',
    'AI financial coaching',
    'iOS and Android apps',
    'Multi-currency support',
    'Offline mode with encrypted local storage',
];

export default function AboutPage() {
    return (
        <div className="min-h-screen bg-background text-foreground">
            <Helmet>
                <title>How it works — Financial Freedom Planner AI</title>
                <meta name="description" content="How Financial Freedom Planner AI works: stage one eliminates debt with snowball or avalanche rolling payments, stage two redirects freed-up money into savings. Privacy, data handling and disclaimers explained." />
            </Helmet>
            <Header />

            <main className="mx-auto w-full max-w-[56rem] px-5 py-16 sm:px-8">
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">About</p>
                <h1 className="mt-3 font-display text-4xl font-semibold leading-tight sm:text-5xl">
                    How Financial Freedom Planner AI Works
                </h1>
                <p className="mt-5 text-lg text-muted-foreground">
                    Understand your money. Eliminate debt. Build wealth. Two stages, one continuous curve of momentum.
                </p>

                <div className="mt-14 space-y-14">
                    {sections.map((s) => (
                        <Reveal key={s.id}>
                            <section id={s.id} className="scroll-mt-28">
                                <h2 className="font-display text-2xl font-semibold sm:text-3xl">{s.heading}</h2>
                                <div className="mt-4 space-y-4">
                                    {s.paras.map((p) => (
                                        <p key={p.slice(0, 40)} className="text-base leading-relaxed text-muted-foreground">{p}</p>
                                    ))}
                                </div>
                            </section>
                        </Reveal>
                    ))}

                    <Reveal>
                        <section>
                            <h2 className="font-display text-2xl font-semibold sm:text-3xl">Where this is heading</h2>
                            <p className="mt-4 text-muted-foreground">
                                The architecture is deliberately modular so these can arrive without disturbing what already works:
                            </p>
                            <ul className="mt-5 grid gap-2 sm:grid-cols-2">
                                {roadmap.map((r) => (
                                    <li key={r} className="flex items-start gap-2 rounded-xl bg-secondary/60 px-3 py-2.5 text-sm">
                                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(var(--accent2))]" aria-hidden="true" />
                                        {r}
                                    </li>
                                ))}
                            </ul>
                        </section>
                    </Reveal>
                </div>

                <Link
                    to="/planner"
                    className="mt-16 inline-flex h-14 items-center rounded-full bg-primary px-8 text-base font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5 active:scale-[0.98]"
                >
                    Open the planner
                </Link>
            </main>

            <Footer />
        </div>
    );
}
