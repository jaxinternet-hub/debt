import React from 'react';
import {
    Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend,
    Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { ArrowDownRight, ArrowUpRight, Repeat } from 'lucide-react';
import CountUp from '@/components/CountUp';
import Reveal from '@/components/Reveal';
import { usePlanner } from '@/state/PlannerContext';
import { formatGBP } from '@/lib/finance';

export function SectionHeading({ eyebrow, title, children }) {
    return (
        <div className="mb-6">
            {eyebrow && <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{eyebrow}</p>}
            <h2 className="mt-2 font-display text-2xl font-semibold sm:text-3xl">{title}</h2>
            {children && <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{children}</p>}
        </div>
    );
}

export function Panel({ title, hint, children, className = '' }) {
    return (
        <section className={`rounded-3xl border border-border bg-card p-5 sm:p-6 ${className}`}>
            {title && (
                <header className="mb-4">
                    <h3 className="font-display text-lg font-semibold">{title}</h3>
                    {hint && <p className="mt-1 text-sm text-muted-foreground">{hint}</p>}
                </header>
            )}
            {children}
        </section>
    );
}

const chartTooltip = {
    contentStyle: {
        borderRadius: 14,
        border: '1px solid hsl(var(--border))',
        background: 'hsl(var(--card))',
        color: 'hsl(var(--card-foreground))',
        fontSize: 13,
    },
    labelStyle: { color: 'hsl(var(--muted-foreground))' },
};

function Metric({ label, value, tone = 'neutral', hint, decimals = 0 }) {
    const toneClass = tone === 'up' ? 'text-[hsl(var(--positive))]' : tone === 'down' ? 'text-destructive' : 'text-foreground';
    return (
        <div className="rounded-2xl border border-border bg-card p-5">
            <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
            <p className={`tabular mt-2 font-display text-[1.7rem] font-semibold leading-none ${toneClass}`}>
                <CountUp value={value} prefix={value < 0 ? '-£' : '£'} decimals={decimals} />
            </p>
            {hint && <p className="mt-2 text-xs text-muted-foreground">{hint}</p>}
        </div>
    );
}

export default function Dashboard() {
    const { summary, recurring, transactions } = usePlanner();
    if (!summary) return null;

    const pie = summary.categories.filter((c) => c.total > 0);
    const subs = recurring.filter((r) => r.direction === 'debit' && r.category !== 'Debt' && r.amount <= 120).slice(0, 8);
    const incomeStreams = recurring.filter((r) => r.direction === 'credit').slice(0, 4);
    const monthlySeries = summary.cashFlow.map((m) => ({
        ...m,
        label: new Date(`${m.month}-01`).toLocaleDateString('en-GB', { month: 'short' }),
    }));
    const abs = (v) => Math.abs(v);

    return (
        <div className="space-y-12">
            <div>
                <SectionHeading eyebrow="Your month at a glance" title="The honest picture">
                    Averages across {summary.months} month{summary.months > 1 ? 's' : ''} of statements
                    · {summary.transactionCount} transactions categorised · balance columns ignored.
                </SectionHeading>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    <Metric label="Monthly income" value={summary.monthlyIncome} tone="up" hint="Salary, benefits, refunds, transfers in" />
                    <Metric label="Monthly spending" value={summary.monthlySpending} tone="down" hint="Everything leaving the account" />
                    <Metric label="Disposable income" value={summary.disposable} tone={summary.disposable >= 0 ? 'up' : 'down'} hint="What is left before you decide" />
                    <Metric label="Savings each month" value={summary.savingsPayments} hint="ISAs, savings, investments, pension" />
                    <Metric label="Debt payments" value={summary.debtPayments} tone="down" hint="Loans, cards, finance, BNPL" />
                    <Metric label="Housing & bills" value={summary.essentials} hint="Rent or mortgage, utilities, insurance" />
                    <Metric label="Net position" value={summary.netPosition} tone={summary.netPosition >= 0 ? 'up' : 'down'} hint="Income minus everything out" />
                    <div className="rounded-2xl border border-border bg-primary p-5 text-primary-foreground">
                        <p className="text-xs uppercase tracking-[0.14em] opacity-80">Monthly cash flow</p>
                        <p className="tabular mt-2 font-display text-[1.7rem] font-semibold leading-none">
                            {summary.netPosition >= 0 ? 'Positive' : 'Negative'}
                        </p>
                        <p className="mt-2 flex items-center gap-1 text-xs opacity-90">
                            {summary.netPosition >= 0
                                ? <><ArrowUpRight className="h-4 w-4" strokeWidth={2} /> {formatGBP(summary.netPosition)} of headroom</>
                                : <><ArrowDownRight className="h-4 w-4" strokeWidth={2} /> {formatGBP(abs(summary.netPosition))} short each month</>}
                        </p>
                    </div>
                </div>
            </div>

            <div>
                <SectionHeading eyebrow="Spending breakdown" title="Where it goes" />
                <div className="grid gap-4 lg:grid-cols-2">
                    <Panel title="Category split" hint="Share of everything that left your account">
                        <div className="h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={pie} dataKey="total" nameKey="name" innerRadius="52%" outerRadius="80%" paddingAngle={2} stroke="none">
                                        {pie.map((c) => <Cell key={c.name} fill={c.color} />)}
                                    </Pie>
                                    <Tooltip {...chartTooltip} formatter={(v, n) => [formatGBP(v), n]} />
                                    <Legend wrapperStyle={{ fontSize: 12 }} />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    </Panel>

                    <Panel title="Monthly cost by category" hint="Average per month, largest first">
                        <div className="h-72">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={pie.slice(0, 8)} layout="vertical" margin={{ left: 8, right: 16 }}>
                                    <CartesianGrid horizontal={false} stroke="hsl(var(--border))" />
                                    <XAxis type="number" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `£${v}`} />
                                    <YAxis type="category" dataKey="name" width={92} tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                                    <Tooltip {...chartTooltip} formatter={(v) => formatGBP(v)} />
                                    <Bar dataKey="monthly" radius={[0, 8, 8, 0]}>
                                        {pie.slice(0, 8).map((c) => <Cell key={c.name} fill={c.color} />)}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Panel>

                    <Panel title="Monthly trend" hint="Income against spending, month by month">
                        <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={monthlySeries}>
                                    <defs>
                                        <linearGradient id="inc" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="0%" stopColor="hsl(var(--positive))" stopOpacity={0.5} />
                                            <stop offset="100%" stopColor="hsl(var(--positive))" stopOpacity={0.04} />
                                        </linearGradient>
                                        <linearGradient id="spd" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="0%" stopColor="hsl(var(--accent2))" stopOpacity={0.5} />
                                            <stop offset="100%" stopColor="hsl(var(--accent2))" stopOpacity={0.04} />
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                                    <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `£${v}`} />
                                    <Tooltip {...chartTooltip} formatter={(v) => formatGBP(v)} />
                                    <Area type="monotone" dataKey="income" stroke="hsl(var(--positive))" fill="url(#inc)" strokeWidth={2} />
                                    <Area type="monotone" dataKey="spending" stroke="hsl(var(--accent2))" fill="url(#spd)" strokeWidth={2} />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </Panel>

                    <Panel title="Debt vs income vs savings" hint="How each month is divided">
                        <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={[
                                    { name: 'Income', value: summary.monthlyIncome, fill: 'hsl(var(--positive))' },
                                    { name: 'Housing', value: summary.essentials, fill: '#2f7d78' },
                                    { name: 'Debt', value: summary.debtPayments, fill: '#d1603d' },
                                    { name: 'Savings', value: summary.savingsPayments, fill: '#3f7fbf' },
                                    { name: 'Other', value: Math.max(0, summary.monthlySpending - summary.essentials - summary.debtPayments - summary.savingsPayments), fill: '#9a8f80' },
                                ]}>
                                    <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} />
                                    <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `£${v}`} />
                                    <Tooltip {...chartTooltip} formatter={(v) => formatGBP(v)} />
                                    <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                                        {['a', 'b', 'c', 'd', 'e'].map((k, i) => (
                                            <Cell key={k} fill={['hsl(var(--positive))', '#2f7d78', '#d1603d', '#3f7fbf', '#9a8f80'][i]} />
                                        ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Panel>
                </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
                <Panel title="Largest single expenses" hint="Worth a second look">
                    <ul className="divide-y divide-border">
                        {summary.largest.map((t) => (
                            <li key={t.id} className="flex items-center justify-between gap-4 py-3">
                                <div className="min-w-0">
                                    <p className="truncate text-sm font-medium">{t.description}</p>
                                    <p className="text-xs text-muted-foreground">{t.date} · {t.category}{t.subCategory ? ` · ${t.subCategory}` : ''}</p>
                                </div>
                                <span className="tabular shrink-0 text-sm font-semibold">{formatGBP(Math.abs(t.amount), 2)}</span>
                            </li>
                        ))}
                    </ul>
                </Panel>

                <div className="space-y-4">
                    <Panel title="Recurring subscriptions & bills" hint="Detected across two or more months">
                        {subs.length ? (
                            <ul className="space-y-2">
                                {subs.map((r) => (
                                    <li key={r.description} className="flex items-center justify-between gap-3 rounded-xl bg-secondary/60 px-3 py-2.5 text-sm">
                                        <span className="flex min-w-0 items-center gap-2">
                                            <Repeat className="h-4 w-4 shrink-0 text-primary" strokeWidth={1.7} />
                                            <span className="truncate">{r.description}</span>
                                        </span>
                                        <span className="tabular shrink-0 font-semibold">{formatGBP(r.amount, 2)}<span className="text-xs font-normal text-muted-foreground">/mo</span></span>
                                    </li>
                                ))}
                            </ul>
                        ) : <p className="text-sm text-muted-foreground">No repeating payments detected yet — upload two or more months to spot them.</p>}
                    </Panel>

                    <Panel title="Recurring income" hint="Regular money arriving">
                        {incomeStreams.length ? (
                            <ul className="space-y-2 text-sm">
                                {incomeStreams.map((r) => (
                                    <li key={r.description} className="flex items-center justify-between gap-3 rounded-xl bg-accent/50 px-3 py-2.5">
                                        <span className="truncate">{r.description}</span>
                                        <span className="tabular shrink-0 font-semibold">{formatGBP(r.amount, 2)}</span>
                                    </li>
                                ))}
                            </ul>
                        ) : <p className="text-sm text-muted-foreground">No repeating income detected in this period.</p>}
                    </Panel>
                </div>
            </div>

            <Reveal>
                <Panel title="Every categorised transaction" hint={`${transactions.length} rows — scroll to review or correct nothing at all`}>
                    <div className="max-h-80 overflow-auto rounded-xl border border-border">
                        <table className="w-full text-left text-sm">
                            <thead className="sticky top-0 bg-secondary text-xs uppercase tracking-wide text-muted-foreground">
                                <tr>
                                    <th className="px-3 py-2 font-medium">Date</th>
                                    <th className="px-3 py-2 font-medium">Description</th>
                                    <th className="px-3 py-2 font-medium">Category</th>
                                    <th className="px-3 py-2 text-right font-medium">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {transactions.slice(0, 400).map((t) => (
                                    <tr key={t.id} className="border-t border-border">
                                        <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">{t.date}</td>
                                        <td className="max-w-[16rem] truncate px-3 py-2">{t.description}</td>
                                        <td className="px-3 py-2">
                                            <span className="rounded-full bg-secondary px-2 py-0.5 text-xs">{t.category}</span>
                                        </td>
                                        <td className={`tabular whitespace-nowrap px-3 py-2 text-right ${t.amount > 0 ? 'text-[hsl(var(--positive))]' : ''}`}>
                                            {t.amount > 0 ? '+' : ''}{formatGBP(t.amount, 2)}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Panel>
            </Reveal>
        </div>
    );
}

export { Metric, chartTooltip };
