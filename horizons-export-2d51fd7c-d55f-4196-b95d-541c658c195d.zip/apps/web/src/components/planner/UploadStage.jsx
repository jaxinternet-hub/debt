import React, { useCallback, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { UploadCloud, ShieldAlert, Loader2, Wand2, RotateCcw } from 'lucide-react';
import { usePlanner } from '@/state/PlannerContext';
import { ingestFile } from '@/lib/ingest';
import { demoTransactions } from '@/lib/finance';

const MASK_LIST = [
    'Account numbers', 'Sort codes', 'Addresses', 'Customer IDs', 'Statement references',
    'QR codes', 'Barcodes', 'Personal notes', 'Any sensitive information',
];

function PrivacyModal({ onCancel, onContinue }) {
    return (
        <div className="fixed inset-0 z-50 grid place-items-center bg-foreground/40 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-labelledby="privacy-title">
            <motion.div
                initial={{ opacity: 0, y: 18, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.25, ease: 'easeOut' }}
                className="max-h-[88vh] w-full max-w-xl overflow-y-auto rounded-3xl border border-border bg-card p-7 shadow-2xl"
            >
                <div className="flex items-center gap-3">
                    <span className="grid h-11 w-11 place-items-center rounded-2xl bg-accent text-accent-foreground">
                        <ShieldAlert className="h-5 w-5" strokeWidth={1.8} />
                    </span>
                    <h2 id="privacy-title" className="font-display text-2xl font-semibold">Before Uploading</h2>
                </div>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                    This application only needs transaction descriptions and payment amounts. For your privacy we strongly
                    recommend removing or masking:
                </p>
                <ul className="mt-4 grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
                    {MASK_LIST.map((m) => (
                        <li key={m} className="flex items-start gap-2 rounded-xl bg-secondary/70 px-3 py-2">
                            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(var(--accent2))]" aria-hidden="true" />
                            {m}
                        </li>
                    ))}
                </ul>
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                    The AI only needs transaction descriptions, dates and payment amounts to analyse spending.
                    We never require login credentials. We never ask for online banking access.
                </p>
                <div className="mt-7 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                    <button type="button" onClick={onCancel} className="h-12 rounded-full border border-border px-6 text-sm font-medium transition-transform active:scale-[0.98]">
                        Cancel
                    </button>
                    <button type="button" onClick={onContinue} className="h-12 rounded-full bg-primary px-7 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-px active:scale-[0.98]">
                        Continue
                    </button>
                </div>
            </motion.div>
        </div>
    );
}

export default function UploadStage() {
    const { loadTransactions, hasSaved, restoreSession, notify } = usePlanner();
    const [modalOpen, setModalOpen] = useState(false);
    const [busy, setBusy] = useState('');
    const [error, setError] = useState('');
    const [dragging, setDragging] = useState(false);
    const inputRef = useRef(null);

    const handleFiles = useCallback(async (files) => {
        const list = Array.from(files || []);
        if (!list.length) return;
        setError('');
        const collected = [];
        try {
            for (const file of list) {
                setBusy(`Analysing ${file.name}`);
                // eslint-disable-next-line no-await-in-loop
                const { transactions } = await ingestFile(file, (stage) => setBusy(`${file.name}: ${stage}`));
                collected.push(...transactions);
            }
            if (!collected.length) {
                setError('No transactions could be read from that file. Try a CSV export, or a clearer photo if you used OCR.');
                return;
            }
            loadTransactions(collected, list.map((f) => f.name).join(', '));
            notify('Statement analysed', `${collected.length} transactions categorised in your browser.`, 'success');
        } catch (e) {
            setError(e?.message || 'Something went wrong reading that file.');
        } finally {
            setBusy('');
        }
    }, [loadTransactions, notify]);

    const openPicker = () => {
        setModalOpen(false);
        inputRef.current?.click();
    };

    return (
        <div className="mx-auto w-full max-w-[60rem] px-5 py-14 sm:px-8">
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Step one</p>
            <h1 className="mt-3 font-display text-3xl font-semibold leading-tight sm:text-5xl">
                Let&apos;s see where your money actually goes.
            </h1>
            <p className="mt-4 max-w-2xl text-muted-foreground">
                Everything is processed on this device. Nothing is uploaded, and nothing is kept when you close the tab
                unless you press save.
            </p>

            <div
                onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                onDragLeave={() => setDragging(false)}
                onDrop={(e) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
                className={`mt-9 rounded-[2rem] border-2 border-dashed p-9 text-center transition-colors ${dragging ? 'border-primary bg-accent/50' : 'border-border bg-card'}`}
            >
                <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-accent text-accent-foreground">
                    {busy ? <Loader2 className="h-7 w-7 animate-spin" strokeWidth={1.8} /> : <UploadCloud className="h-7 w-7" strokeWidth={1.7} />}
                </span>
                <p className="mt-5 font-display text-xl font-semibold">
                    {busy || 'Drop your statement here'}
                </p>
                <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
                    PDF, CSV, Excel, Open Banking JSON, screenshots and photos. Scanned pages are read with built-in OCR,
                    which can take a few moments.
                </p>
                <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
                    <button
                        type="button"
                        disabled={!!busy}
                        onClick={() => setModalOpen(true)}
                        className="inline-flex min-h-[3rem] items-center gap-2 rounded-full bg-primary px-7 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-px active:scale-[0.98] disabled:opacity-60"
                    >
                        <UploadCloud className="h-5 w-5" strokeWidth={1.8} />
                        Choose a file
                    </button>
                    <button
                        type="button"
                        disabled={!!busy}
                        onClick={() => { loadTransactions(demoTransactions(4), 'Sample household statement'); notify('Sample data loaded', 'Four months of a realistic UK household statement.', 'info'); }}
                        className="inline-flex min-h-[3rem] items-center gap-2 rounded-full border border-border bg-background px-6 text-sm font-medium transition-transform hover:-translate-y-px active:scale-[0.98]"
                    >
                        <Wand2 className="h-5 w-5" strokeWidth={1.7} />
                        Use sample data
                    </button>
                    {hasSaved && (
                        <button
                            type="button"
                            onClick={() => { if (!restoreSession()) setError('The saved session could not be read.'); }}
                            className="inline-flex min-h-[3rem] items-center gap-2 rounded-full border border-border bg-background px-6 text-sm font-medium"
                        >
                            <RotateCcw className="h-5 w-5" strokeWidth={1.7} />
                            Restore saved session
                        </button>
                    )}
                </div>
                <input
                    ref={inputRef}
                    type="file"
                    className="sr-only"
                    multiple
                    accept=".csv,.tsv,.txt,.json,.pdf,.xlsx,.xls,.ods,image/*"
                    onChange={(e) => handleFiles(e.target.files)}
                />
            </div>

            {error && (
                <p role="alert" className="mt-5 rounded-2xl border border-destructive/40 bg-destructive/10 px-5 py-4 text-sm text-destructive">
                    {error}
                </p>
            )}

            <div className="mt-10 grid gap-4 sm:grid-cols-3">
                {[
                    ['No login, ever', 'We never ask for online banking access or credentials.'],
                    ['Client-side analysis', 'Parsing, OCR and categorisation all run in this browser tab.'],
                    ['Nothing stored', 'Data disappears on refresh unless you explicitly save it to this device.'],
                ].map(([t, b]) => (
                    <div key={t} className="rounded-2xl border border-border bg-card p-5">
                        <p className="font-display text-base font-semibold">{t}</p>
                        <p className="mt-1.5 text-sm text-muted-foreground">{b}</p>
                    </div>
                ))}
            </div>

            {modalOpen && <PrivacyModal onCancel={() => setModalOpen(false)} onContinue={openPicker} />}
        </div>
    );
}
