import React, { useRef, useState } from 'react';
import { Bell, Download, FileDown, Lightbulb, Send, Sparkles } from 'lucide-react';
import { Panel, SectionHeading } from '@/components/planner/Dashboard';
import CountUp from '@/components/CountUp';
import { usePlanner } from '@/state/PlannerContext';
import { addMonths, answerQuestion, formatGBP } from '@/lib/finance';
import { downloadFile, transactionsToCsv } from '@/lib/ingest';

export function HealthScore() {
    const { health } = usePlanner();
    if (!health) return null;
    const circumference = 2 * Math.PI * 54;
    const offset = circumference * (1 - health.score / 100);
    return (
        <Panel title="Financial health score" hint="A rough gauge, not a judgement. Every part below is improvable.">
            <div className="flex flex-col gap-8 sm:flex-row sm:items-center">
                <div className="relative mx-auto h-40 w-40 shrink-0">
                    <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
                        <circle cx="60" cy="60" r="54" fill="none" stroke="hsl(var(--secondary))" strokeWidth="11" />
                        <circle
                            cx="60" cy="60" r="54" fill="none" stroke="hsl(var(--primary))" strokeWidth="11"
                            strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset}
                            style={{ transition: 'stroke-dashoffset 900ms cubic-bezier(0.22,1,0.36,1)' }}
                        />
                    </svg>
                    <div className="absolute inset-0 grid place-items-center text-center">
                        <div>
                            <p className="tabular font-display text-3xl font-semibold"><CountUp value={health.score} /></p>
                            <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{health.band}</p>
                        </div>
                    </div>
                </div>
                <ul className="flex-1 space-y-3">
                    {health.parts.map((p) => (
                        <li key={p.label}>
                            <div className="flex items-baseline justify-between text-sm">
                                <span className="font-medium">{p.label}</span>
                                <span className="tabular text-xs text-muted-foreground">{Math.round(p.score * 100)}%</span>
                            </div>
                            <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-secondary">
                                <div className="h-full rounded-full bg-primary transition-[width] duration-700" style={{ width: `${Math.round(p.score * 100)}%` }} />
                            </div>
                            <p className="mt-1.5 text-xs text-muted-foreground">{p.tip}</p>
                        </li>
                    ))}
                </ul>
            </div>
        </Panel>
    );
}

export function Optimiser() {
    const { recs } = usePlanner();
    const total = recs.reduce((s, r) => s + r.saving, 0);
    return (
        <Panel
            title="Budget optimiser"
            hint={total > 0 ? `Achievable target: about ${formatGBP(total)} a month freed up — ${formatGBP(total * 12)} a year.` : 'Small, kind adjustments only. Nothing here requires giving up your life.'}
        >
            <ul className="space-y-3">
                {recs.map((r) => (
                    <li key={r.title} className="rounded-2xl border border-border p-4">
                        <div className="flex items-start gap-3">
                            <Lightbulb className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(var(--accent2))]" strokeWidth={1.7} />
                            <div className="min-w-0">
                                <p className="font-display text-base font-semibold">{r.title}</p>
                                <p className="mt-1 text-sm text-muted-foreground">{r.detail}</p>
                            </div>
                            {r.saving > 0 && (
                                <span className="tabular ml-auto shrink-0 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
                                    ~{formatGBP(r.saving)}/mo
                                </span>
                            )}
                        </div>
                    </li>
                ))}
            </ul>
        </Panel>
    );
}

export function WhatIf() {
    const { whatIf, setWhatIf, summary, plan, savings } = usePlanner();
    const sliders = [
        { key: 'income', label: 'Extra monthly income', max: 1500, step: 25 },
        { key: 'spendingCut', label: 'Monthly spending reduced by', max: 800, step: 10 },
        { key: 'extraDebt', label: 'Extra towards debt', max: 800, step: 10 },
        { key: 'cancelSubs', label: 'Subscriptions cancelled', max: 200, step: 5 },
    ];
    return (
        <Panel title="What if…" hint="Move a slider and every number on this page updates, including the payoff date.">
            <div className="grid gap-5 sm:grid-cols-2">
                {sliders.map((s) => (
                    <label key={s.key} htmlFor={`wi-${s.key}`} className="text-sm font-medium">
                        {s.label}: <span className="tabular font-semibold">{formatGBP(whatIf[s.key])}</span>
                        <input
                            id={`wi-${s.key}`}
                            type="range"
                            min="0"
                            max={s.max}
                            step={s.step}
                            value={whatIf[s.key]}
                            onChange={(e) => setWhatIf((w) => ({ ...w, [s.key]: Number(e.target.value) }))}
                            className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full bg-secondary accent-[hsl(var(--primary))]"
                        />
                    </label>
                ))}
            </div>
            <div className="mt-6 grid gap-3 sm:grid-cols-3">
                {[
                    ['New disposable income', formatGBP(summary?.disposable || 0)],
                    ['Debt free by', plan.months ? addMonths(plan.months) : 'Already there'],
                    ['Savings in 10 years', formatGBP(savings[4]?.total || 0)],
                ].map(([label, value]) => (
                    <div key={label} className="rounded-2xl bg-secondary/70 p-4">
                        <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground">{label}</p>
                        <p className="mt-1.5 font-display text-lg font-semibold">{value}</p>
                    </div>
                ))}
            </div>
            <button
                type="button"
                onClick={() => setWhatIf({ income: 0, spendingCut: 0, extraDebt: 0, cancelSubs: 0 })}
                className="mt-5 h-11 rounded-full border border-border px-5 text-sm font-medium active:scale-[0.98]"
            >
                Reset scenario
            </button>
        </Panel>
    );
}

const SUGGESTIONS = [
    'Where is my money going?',
    'What can I cancel?',
    'Which debt should I pay first?',
    'How much could I save?',
    'Can I afford another loan?',
    "How long until I'm debt free?",
    'What happens if I pay £100 extra?',
];

export function Assistant() {
    const ctx = usePlanner();
    const [messages, setMessages] = useState([{
        role: 'assistant',
        text: 'Ask me anything about your statement. I answer from the numbers on this page — nothing leaves your browser.',
    }]);
    const [input, setInput] = useState('');
    const endRef = useRef(null);

    const ask = (text) => {
        const q = (text ?? input).trim();
        if (!q) return;
        const reply = answerQuestion(q, {
            summary: ctx.summary, debts: ctx.debts, plan: ctx.plan, baseline: ctx.baseline,
            savings: ctx.savings, recs: ctx.recs, health: ctx.health,
        });
        setMessages((m) => [...m, { role: 'user', text: q }, { role: 'assistant', text: reply }]);
        setInput('');
        requestAnimationFrame(() => endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }));
    };

    return (
        <Panel title="Assistant" hint="Plain-English answers, generated on your device from your own figures.">
            <div className="max-h-80 space-y-3 overflow-y-auto pr-1">
                {messages.map((m, i) => (
                    <div key={`${m.role}-${i}`} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <p className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary/80'}`}>
                            {m.text}
                        </p>
                    </div>
                ))}
                <div ref={endRef} />
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                    <button key={s} type="button" onClick={() => ask(s)} className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground">
                        {s}
                    </button>
                ))}
            </div>
            <form
                onSubmit={(e) => { e.preventDefault(); ask(); }}
                className="mt-4 flex gap-2"
            >
                <label className="sr-only" htmlFor="assistant-input">Your question</label>
                <input
                    id="assistant-input"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="e.g. what happens if I pay £150 extra?"
                    className="h-12 flex-1 rounded-full border border-border bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <button type="submit" className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground active:scale-95" aria-label="Send question">
                    <Send className="h-5 w-5" strokeWidth={1.8} />
                </button>
            </form>
        </Panel>
    );
}

export function Notifications() {
    const { notifications } = usePlanner();
    return (
        <Panel title="Alerts & reminders" hint="Generated from this analysis. Nothing is emailed anywhere.">
            {notifications.length ? (
                <ul className="space-y-3">
                    {notifications.map((n) => (
                        <li key={n.id} className={`flex items-start gap-3 rounded-2xl border p-4 ${n.tone === 'warn' ? 'border-destructive/40 bg-destructive/10' : n.tone === 'success' ? 'border-[hsl(var(--positive))]/40 bg-[hsl(var(--positive))]/10' : 'border-border bg-secondary/50'}`}>
                            <Bell className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" strokeWidth={1.7} />
                            <div>
                                <p className="text-sm font-semibold">{n.title}</p>
                                <p className="mt-1 text-sm text-muted-foreground">{n.detail}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            ) : <p className="text-sm text-muted-foreground">No alerts yet.</p>}
        </Panel>
    );
}

export function Reports() {
    const ctx = usePlanner();
    const { summary, debts, plan, savings, recs, health, transactions, baseline } = ctx;
    if (!summary) return null;

    const printReport = () => window.print();

    const exportCsv = () => downloadFile('categorised-transactions.csv', transactionsToCsv(transactions));

    const exportPlan = () => {
        const lines = [
            'Financial Freedom Planner AI — plan summary',
            `Generated ${new Date().toLocaleString('en-GB')}`,
            '',
            `Monthly income: ${formatGBP(summary.monthlyIncome)}`,
            `Monthly spending: ${formatGBP(summary.monthlySpending)}`,
            `Disposable income: ${formatGBP(summary.disposable)}`,
            `Financial health score: ${health.score}/100 (${health.band})`,
            '',
            'Debts:',
            ...debts.map((d) => ` - ${d.name} (${d.type}): balance ${formatGBP(d.balance)}, ${d.apr}% APR, ${formatGBP(d.monthlyPayment)}/mo`),
            '',
            `Method: ${plan.method}`,
            `Debt free: ${plan.months ? addMonths(plan.months) : 'no debts detected'} (${plan.months} months)`,
            `Interest under plan: ${formatGBP(plan.totalInterest)} vs ${formatGBP(baseline.totalInterest)} on minimums only`,
            '',
            'Savings projection:',
            ...savings.map((s) => ` - ${s.label}: ${formatGBP(s.total)}`),
            '',
            'Recommendations:',
            ...recs.map((r) => ` - ${r.title}${r.saving ? ` (~${formatGBP(r.saving)}/mo)` : ''}: ${r.detail}`),
            '',
            'Educational illustration only. Not financial advice.',
        ];
        downloadFile('financial-freedom-plan.txt', lines.join('\n'), 'text/plain;charset=utf-8');
    };

    return (
        <Panel title="Reports & exports" hint="Print or save a PDF of this whole plan, or take your data with you.">
            <div className="flex flex-wrap gap-3">
                <button type="button" onClick={printReport} className="inline-flex min-h-[3rem] items-center gap-2 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground active:scale-[0.98]">
                    <FileDown className="h-5 w-5" strokeWidth={1.8} /> Save as PDF
                </button>
                <button type="button" onClick={exportCsv} className="inline-flex min-h-[3rem] items-center gap-2 rounded-full border border-border px-6 text-sm font-medium active:scale-[0.98]">
                    <Download className="h-5 w-5" strokeWidth={1.7} /> Export transactions (CSV)
                </button>
                <button type="button" onClick={exportPlan} className="inline-flex min-h-[3rem] items-center gap-2 rounded-full border border-border px-6 text-sm font-medium active:scale-[0.98]">
                    <Sparkles className="h-5 w-5" strokeWidth={1.7} /> Export plan summary
                </button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
                The PDF includes your budget, charts, debt plan, savings forecast and recommendations — use your browser&apos;s
                &quot;Save as PDF&quot; destination. Monthly and annual reviews simply mean running this again with a fresh statement.
            </p>
        </Panel>
    );
}

export default function Coach() {
    return (
        <div className="space-y-4">
            <SectionHeading eyebrow="Coaching" title="Gentle, specific next steps" />
            <HealthScore />
            <Optimiser />
            <WhatIf />
            <Assistant />
            <Notifications />
            <Reports />
        </div>
    );
}
