import React, { useState } from 'react';
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Plus, Target, Trash2 } from 'lucide-react';
import { Panel, SectionHeading, chartTooltip } from '@/components/planner/Dashboard';
import CountUp from '@/components/CountUp';
import { usePlanner } from '@/state/PlannerContext';
import { addMonths, formatGBP, projectSavings } from '@/lib/finance';

const GOAL_TEMPLATES = ['Emergency Fund', 'Holiday', 'New Car', 'House Deposit', 'Retirement', 'Education', 'Wedding', 'Custom Goal'];

function Goals() {
    const { goals, setGoals, savingsMonthly } = usePlanner();
    const [draft, setDraft] = useState({ name: 'Holiday', target: 2000, saved: 0, monthly: 150 });

    const add = (e) => {
        e.preventDefault();
        if (!draft.name || draft.target <= 0) return;
        setGoals((g) => [...g, { ...draft, id: `g-${Date.now()}` }]);
        setDraft({ name: 'Holiday', target: 2000, saved: 0, monthly: 150 });
    };

    return (
        <Panel title="Your goals" hint={`Once debts clear you will have around ${formatGBP(savingsMonthly)} a month to aim at these.`}>
            <ul className="space-y-4">
                {goals.map((g) => {
                    const pct = Math.min(100, Math.round((g.saved / Math.max(1, g.target)) * 100));
                    const monthsLeft = g.monthly > 0 ? Math.ceil((g.target - g.saved) / g.monthly) : null;
                    return (
                        <li key={g.id} className="rounded-2xl border border-border p-4">
                            <div className="flex flex-wrap items-center gap-3">
                                <Target className="h-5 w-5 text-primary" strokeWidth={1.7} />
                                <span className="font-display text-base font-semibold">{g.name}</span>
                                <span className="tabular ml-auto text-sm text-muted-foreground">
                                    {formatGBP(g.saved)} of {formatGBP(g.target)}
                                </span>
                                <button
                                    type="button"
                                    onClick={() => setGoals((list) => list.filter((x) => x.id !== g.id))}
                                    aria-label={`Remove ${g.name}`}
                                    className="rounded-full p-2 text-muted-foreground transition-colors hover:text-destructive"
                                >
                                    <Trash2 className="h-4 w-4" strokeWidth={1.7} />
                                </button>
                            </div>
                            <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-secondary">
                                <div className="h-full rounded-full bg-primary transition-[width] duration-500" style={{ width: `${pct}%` }} />
                            </div>
                            <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                                <span>{pct}% there</span>
                                {monthsLeft !== null && <span>· on {formatGBP(g.monthly)}/mo, funded by {addMonths(monthsLeft)}</span>}
                            </div>
                            <div className="mt-3 grid grid-cols-3 gap-2">
                                {[['saved', 'Saved'], ['target', 'Target'], ['monthly', 'Per month']].map(([field, label]) => (
                                    <label key={field} className="text-xs text-muted-foreground">
                                        {label}
                                        <input
                                            type="number"
                                            min="0"
                                            value={g[field]}
                                            onChange={(e) => setGoals((list) => list.map((x) => (x.id === g.id ? { ...x, [field]: Math.max(0, Number(e.target.value) || 0) } : x)))}
                                            className="tabular mt-1 w-full rounded-lg border border-border bg-background px-2 py-1.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                                        />
                                    </label>
                                ))}
                            </div>
                        </li>
                    );
                })}
            </ul>

            <form onSubmit={add} className="mt-5 grid gap-3 rounded-2xl bg-secondary/60 p-4 sm:grid-cols-[1.4fr_1fr_1fr_auto]">
                <label className="text-xs text-muted-foreground">
                    Goal
                    <select
                        value={draft.name}
                        onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
                        className="mt-1 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm text-foreground"
                    >
                        {GOAL_TEMPLATES.map((t) => <option key={t} value={t}>{t}</option>)}
                    </select>
                </label>
                <label className="text-xs text-muted-foreground">
                    Target
                    <input type="number" min="1" value={draft.target} onChange={(e) => setDraft((d) => ({ ...d, target: Number(e.target.value) }))} className="tabular mt-1 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm text-foreground" />
                </label>
                <label className="text-xs text-muted-foreground">
                    Per month
                    <input type="number" min="0" value={draft.monthly} onChange={(e) => setDraft((d) => ({ ...d, monthly: Number(e.target.value) }))} className="tabular mt-1 h-11 w-full rounded-xl border border-border bg-background px-3 text-sm text-foreground" />
                </label>
                <button type="submit" className="mt-auto inline-flex h-11 items-center justify-center gap-1.5 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground active:scale-[0.98]">
                    <Plus className="h-4 w-4" strokeWidth={2} /> Add
                </button>
            </form>
        </Panel>
    );
}

export default function Wealth() {
    const { savings, savingsMonthly, rate, setRate, plan, debts, freedUp } = usePlanner();
    const curve = Array.from({ length: 21 }, (_, y) => {
        const months = y * 12;
        const r = rate / 100 / 12;
        const total = r > 0 && months > 0 ? savingsMonthly * ((Math.pow(1 + r, months) - 1) / r) : savingsMonthly * months;
        return { year: y, total: Math.round(total), contributed: Math.round(savingsMonthly * months) };
    });
    const preview = projectSavings(savingsMonthly, rate);

    return (
        <div className="space-y-12">
            <div>
                <SectionHeading eyebrow="Stage two" title="Then the same money builds wealth">
                    {debts.length
                        ? `From ${addMonths(plan.months)} the ${formatGBP(freedUp)} a month currently servicing debt is free. Redirect it and this is what it becomes.`
                        : `You have no detected debts, so all ${formatGBP(freedUp || savingsMonthly)} a month can go straight to work.`}
                </SectionHeading>

                <div className="rounded-3xl border border-border bg-card p-6">
                    <div className="flex flex-wrap items-end gap-6">
                        <div>
                            <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">Redirected each month</p>
                            <p className="tabular font-display text-3xl font-semibold"><CountUp value={savingsMonthly} prefix="£" /></p>
                        </div>
                        <label htmlFor="rate" className="min-w-[16rem] flex-1 text-sm font-medium">
                            Assumed annual growth: <span className="tabular font-semibold">{rate.toFixed(1)}%</span>
                            <input
                                id="rate"
                                type="range"
                                min="0"
                                max="10"
                                step="0.5"
                                value={rate}
                                onChange={(e) => setRate(Number(e.target.value))}
                                className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full bg-secondary accent-[hsl(var(--primary))]"
                            />
                        </label>
                    </div>

                    <div className="mt-8 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
                        {preview.map((p) => (
                            <div key={p.label} className="rounded-2xl bg-secondary/70 p-4">
                                <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground">{p.label}</p>
                                <p className="tabular mt-2 font-display text-lg font-semibold">{formatGBP(p.total)}</p>
                                <p className="mt-1 text-[11px] text-[hsl(var(--positive))]">{formatGBP(p.growth)} growth</p>
                            </div>
                        ))}
                    </div>

                    <div className="mt-8 h-72">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={curve}>
                                <defs>
                                    <linearGradient id="sv" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.55} />
                                        <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0.03} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                                <XAxis dataKey="year" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `${v}y`} />
                                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `£${Math.round(v / 1000)}k`} />
                                <Tooltip {...chartTooltip} formatter={(v, n) => [formatGBP(v), n === 'total' ? 'With growth' : 'Contributions']} labelFormatter={(l) => `Year ${l}`} />
                                <Area type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#sv)" />
                                <Area type="monotone" dataKey="contributed" stroke="hsl(var(--muted-foreground))" strokeDasharray="4 4" strokeWidth={1.5} fill="none" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>

                    <p className="mt-5 rounded-2xl bg-secondary/70 p-4 text-xs leading-relaxed text-muted-foreground">
                        Projections are illustrative only. They assume a constant growth rate, no charges, no tax and
                        uninterrupted contributions — real markets do none of those things. This is not financial advice.
                    </p>
                </div>
            </div>

            <Goals />
        </div>
    );
}
