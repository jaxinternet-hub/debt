import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { CheckCircle2, Flame, Snowflake, Trophy, PartyPopper } from 'lucide-react';
import { Panel, SectionHeading, chartTooltip } from '@/components/planner/Dashboard';
import { usePlanner } from '@/state/PlannerContext';
import { addMonths, formatGBP } from '@/lib/finance';

function Domino({ debt, index, total, cleared, monthsIn }) {
    return (
        <motion.div
            className="origin-bottom-left"
            initial={{ rotate: 0 }}
            animate={{ rotate: cleared ? -74 : 0, opacity: cleared ? 0.55 : 1 }}
            transition={{ duration: 0.5, ease: [0.34, 1.3, 0.64, 1], delay: cleared ? index * 0.06 : 0 }}
        >
            <div className={`flex h-32 w-[4.6rem] flex-col justify-between rounded-xl border p-2 text-center shadow-md sm:w-20 ${cleared ? 'border-[hsl(var(--positive))]/50 bg-[hsl(var(--positive))]/15' : 'border-border bg-card'}`}>
                <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{index + 1}/{total}</span>
                <span className="line-clamp-3 text-[11px] font-medium leading-tight">{debt.name}</span>
                <span className="tabular text-[11px] font-semibold">
                    {cleared ? `Clear · m${debt.paidMonth}` : formatGBP(debt.balance)}
                </span>
            </div>
            {cleared && monthsIn >= (debt.paidMonth || 0) && (
                <span className="mt-1 block text-[10px] text-[hsl(var(--positive))]">+{formatGBP(debt.monthlyPayment)} rolled</span>
            )}
        </motion.div>
    );
}

export default function DebtPlan() {
    const { debts, method, setMethod, extra, setExtra, plan, baseline, updateDebt, summary } = usePlanner();
    const [monthsIn, setMonthsIn] = useState(0);

    const clearedNow = useMemo(
        () => plan.order.filter((d) => d.paidMonth && d.paidMonth <= monthsIn).length,
        [plan.order, monthsIn],
    );
    const interestSaved = Math.max(0, baseline.totalInterest - plan.totalInterest);
    const monthsSaved = Math.max(0, baseline.months - plan.months);
    const remaining = plan.timeline.find((t) => t.month === monthsIn)?.balance
        ?? (monthsIn === 0 ? debts.reduce((s, d) => s + d.balance, 0) : 0);

    const milestones = useMemo(() => {
        const totalDebt = debts.reduce((s, d) => s + d.balance, 0) || 1;
        const list = [];
        [0.25, 0.5, 0.75].forEach((pct) => {
            const hit = plan.timeline.find((t) => t.balance <= totalDebt * (1 - pct));
            if (hit) list.push({ label: `${pct * 100}% of your debt gone`, month: hit.month });
        });
        if (plan.months) list.push({ label: 'Completely debt free', month: plan.months });
        return list;
    }, [plan.timeline, plan.months, debts]);

    if (!debts.length) {
        return (
            <Panel title="No debts detected" hint="Nothing in this statement matched a known credit agreement.">
                <p className="text-sm text-muted-foreground">
                    That means you are already at stage two. Head to the Build Wealth section to project what your spare
                    income becomes over the next 20 years.
                </p>
            </Panel>
        );
    }

    return (
        <div className="space-y-12">
            <div>
                <SectionHeading eyebrow="Stage one" title="Your detected debts">
                    Balances and interest rates are estimated from payment size and product type. Edit any number to make the
                    plan match your real paperwork — priority scores update instantly.
                </SectionHeading>
                <div className="overflow-x-auto rounded-3xl border border-border bg-card">
                    <table className="w-full min-w-[54rem] text-left text-sm">
                        <thead className="bg-secondary text-xs uppercase tracking-wide text-muted-foreground">
                            <tr>
                                <th className="px-4 py-3 font-medium">Debt</th>
                                <th className="px-4 py-3 font-medium">Type</th>
                                <th className="px-4 py-3 text-right font-medium">Est. balance</th>
                                <th className="px-4 py-3 text-right font-medium">Min payment</th>
                                <th className="px-4 py-3 text-right font-medium">APR %</th>
                                <th className="px-4 py-3 text-right font-medium">You pay / mo</th>
                                <th className="px-4 py-3 text-right font-medium">Priority</th>
                            </tr>
                        </thead>
                        <tbody>
                            {debts.map((d) => (
                                <tr key={d.id} className="border-t border-border">
                                    <td className="px-4 py-3 font-medium">{d.name}</td>
                                    <td className="px-4 py-3 text-muted-foreground">{d.type}</td>
                                    {[['balance', 0], ['minPayment', 2], ['apr', 1], ['monthlyPayment', 2]].map(([field, dec]) => (
                                        <td key={field} className="px-4 py-2 text-right">
                                            <label className="sr-only" htmlFor={`${d.id}-${field}`}>{`${d.name} ${field}`}</label>
                                            <input
                                                id={`${d.id}-${field}`}
                                                type="number"
                                                step={dec === 0 ? 10 : 0.5}
                                                min="0"
                                                value={d[field]}
                                                onChange={(e) => updateDebt(d.id, { [field]: Math.max(0, Number(e.target.value) || 0) })}
                                                className="tabular w-24 rounded-lg border border-border bg-background px-2 py-1.5 text-right focus:outline-none focus:ring-2 focus:ring-ring"
                                            />
                                        </td>
                                    ))}
                                    <td className="px-4 py-3 text-right">
                                        <span className="tabular rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-accent-foreground">{d.priority}</span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                <SectionHeading eyebrow="Debt elimination engine" title="Snowball or avalanche?">
                    Both work. Snowball wins on motivation, avalanche wins on arithmetic. Pick the one you will actually stick to.
                </SectionHeading>
                <div className="grid gap-4 md:grid-cols-2">
                    {[
                        { id: 'snowball', icon: Snowflake, title: 'Debt Snowball', body: 'Clear the smallest balance first. Quick early wins build momentum, and each cleared payment rolls into the next debt.' },
                        { id: 'avalanche', icon: Flame, title: 'Debt Avalanche', body: 'Attack the highest interest rate first. Mathematically the cheapest route — usually the least interest paid overall.' },
                    ].map((m) => {
                        const active = method === m.id;
                        return (
                            <button
                                key={m.id}
                                type="button"
                                onClick={() => setMethod(m.id)}
                                aria-pressed={active}
                                className={`rounded-3xl border p-6 text-left transition-transform hover:-translate-y-px active:scale-[0.99] ${active ? 'border-primary bg-accent/60 ring-2 ring-primary/40' : 'border-border bg-card'}`}
                            >
                                <m.icon className="h-7 w-7 text-primary" strokeWidth={1.6} />
                                <p className="mt-3 font-display text-xl font-semibold">{m.title}</p>
                                <p className="mt-2 text-sm text-muted-foreground">{m.body}</p>
                                <p className="mt-4 text-xs font-semibold uppercase tracking-[0.14em] text-primary">
                                    {active ? 'Selected' : 'Choose this method'}
                                </p>
                            </button>
                        );
                    })}
                </div>

                <div className="mt-6 rounded-3xl border border-border bg-card p-6">
                    <label htmlFor="extra" className="block text-sm font-medium">
                        Extra payment each month: <span className="tabular font-semibold">{formatGBP(extra)}</span>
                    </label>
                    <input
                        id="extra"
                        type="range"
                        min="0"
                        max={Math.max(300, Math.round((summary?.disposable || 0) + 200))}
                        step="5"
                        value={extra}
                        onChange={(e) => setExtra(Number(e.target.value))}
                        className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full bg-secondary accent-[hsl(var(--primary))]"
                    />
                    <p className="mt-2 text-xs text-muted-foreground">
                        Even £20 a month changes the finish line. Your disposable income is {formatGBP(summary?.disposable || 0)}.
                    </p>
                </div>
            </div>

            <div>
                <SectionHeading eyebrow="Repayment simulator" title="Watch the dominoes fall">
                    Drag through the months. As each debt clears, its payment rolls into the next priority debt, so the
                    remaining balance falls faster and faster.
                </SectionHeading>

                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {[
                        ['Current month', monthsIn === 0 ? 'Today' : `Month ${monthsIn}`],
                        ['Estimated payoff', addMonths(plan.months)],
                        ['Interest avoided', formatGBP(interestSaved)],
                        ['Time saved', monthsSaved >= 12 ? `${Math.floor(monthsSaved / 12)}y ${monthsSaved % 12}m` : `${monthsSaved} months`],
                    ].map(([label, value]) => (
                        <div key={label} className="rounded-2xl border border-border bg-card p-5">
                            <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">{label}</p>
                            <p className="mt-2 font-display text-xl font-semibold">{value}</p>
                        </div>
                    ))}
                </div>

                <div className="mt-6 rounded-3xl border border-border bg-card p-6">
                    <label htmlFor="timeline" className="flex flex-wrap items-baseline justify-between gap-2 text-sm font-medium">
                        <span>Scrub the plan · month {monthsIn} of {plan.months}</span>
                        <span className="tabular text-muted-foreground">
                            Remaining debt {formatGBP(remaining)} · {clearedNow} of {debts.length} cleared
                        </span>
                    </label>
                    <input
                        id="timeline"
                        type="range"
                        min="0"
                        max={plan.months}
                        value={Math.min(monthsIn, plan.months)}
                        onChange={(e) => setMonthsIn(Number(e.target.value))}
                        className="mt-3 h-2 w-full cursor-pointer appearance-none rounded-full bg-secondary accent-[hsl(var(--primary))]"
                    />

                    <div className="mt-8 flex min-h-[11rem] items-end gap-3 overflow-x-auto pb-2">
                        {plan.order.map((d, i) => (
                            <Domino
                                key={d.id}
                                debt={d}
                                index={i}
                                total={plan.order.length}
                                cleared={!!d.paidMonth && d.paidMonth <= monthsIn}
                                monthsIn={monthsIn}
                            />
                        ))}
                    </div>

                    <div className="mt-8 h-56">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={plan.timeline}>
                                <defs>
                                    <linearGradient id="dbt" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="hsl(var(--accent2))" stopOpacity={0.55} />
                                        <stop offset="100%" stopColor="hsl(var(--accent2))" stopOpacity={0.04} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                                <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `m${v}`} />
                                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `£${Math.round(v / 1000)}k`} />
                                <Tooltip {...chartTooltip} formatter={(v) => formatGBP(v)} labelFormatter={(l) => `Month ${l}`} />
                                <Area type="monotone" dataKey="balance" stroke="hsl(var(--accent2))" strokeWidth={2.5} fill="url(#dbt)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="mt-6 grid gap-4 lg:grid-cols-2">
                    <Panel title="Motivational milestones" hint="Worth marking properly when you get there">
                        <ul className="space-y-3">
                            {milestones.map((m) => {
                                const hit = monthsIn >= m.month;
                                return (
                                    <li key={m.label} className="flex items-center gap-3 rounded-xl bg-secondary/60 px-3 py-3">
                                        {hit
                                            ? <PartyPopper className="h-5 w-5 shrink-0 text-[hsl(var(--positive))]" strokeWidth={1.7} />
                                            : <Trophy className="h-5 w-5 shrink-0 text-muted-foreground" strokeWidth={1.7} />}
                                        <span className="text-sm font-medium">{m.label}</span>
                                        <span className="ml-auto text-xs text-muted-foreground">{addMonths(m.month)}</span>
                                    </li>
                                );
                            })}
                        </ul>
                    </Panel>

                    <Panel title="Payment roll-ups" hint="The compounding effect of the plan">
                        <ul className="space-y-3">
                            {plan.events.map((e) => (
                                <li key={`${e.name}-${e.month}`} className="flex items-center gap-3 text-sm">
                                    <CheckCircle2 className="h-5 w-5 shrink-0 text-[hsl(var(--positive))]" strokeWidth={1.7} />
                                    <span className="min-w-0 flex-1 truncate">
                                        <strong className="font-semibold">{e.name}</strong> cleared in month {e.month}
                                    </span>
                                    <span className="tabular shrink-0 text-xs text-muted-foreground">+{formatGBP(e.rolled)} rolls on</span>
                                </li>
                            ))}
                        </ul>
                    </Panel>
                </div>

                <Panel className="mt-4" title="Method comparison" hint="Total interest paid under each approach">
                    <div className="h-52">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={[
                                { name: 'Minimums only', value: baseline.totalInterest },
                                { name: method === 'avalanche' ? 'Avalanche plan' : 'Snowball plan', value: plan.totalInterest },
                            ]}>
                                <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                                <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `£${Math.round(v)}`} />
                                <Tooltip {...chartTooltip} formatter={(v) => formatGBP(v)} />
                                <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                                    <Cell fill="#d1603d" />
                                    <Cell fill="hsl(var(--positive))" />
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </Panel>
            </div>
        </div>
    );
}
