import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useTheme } from 'next-themes';
import { Moon, Sun, Sprout } from 'lucide-react';

export function ThemeToggle() {
    const { theme, setTheme, systemTheme } = useTheme();
    const current = theme === 'system' ? systemTheme : theme;
    const isDark = current === 'dark';
    return (
        <button
            type="button"
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-border bg-card text-foreground transition-transform hover:-translate-y-px active:scale-95"
        >
            {isDark ? <Sun className="h-5 w-5" strokeWidth={1.6} /> : <Moon className="h-5 w-5" strokeWidth={1.6} />}
        </button>
    );
}

const links = [
    { to: '/', label: 'Home' },
    { to: '/planner', label: 'Planner' },
    { to: '/about', label: 'How it works' },
];

export function Header() {
    return (
        <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur-md">
            <div className="mx-auto flex w-full max-w-[80rem] items-center gap-4 px-5 py-3 sm:px-8">
                <Link to="/" className="flex items-center gap-2.5">
                    <span className="grid h-10 w-10 place-items-center rounded-2xl bg-primary text-primary-foreground">
                        <Sprout className="h-5 w-5" strokeWidth={1.8} />
                    </span>
                    <span className="leading-tight">
                        <span className="block font-display text-base font-semibold tracking-tight">Financial Freedom</span>
                        <span className="block text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Planner AI</span>
                    </span>
                </Link>
                <nav className="ml-auto hidden items-center gap-1 sm:flex">
                    {links.map((l) => (
                        <NavLink
                            key={l.to}
                            to={l.to}
                            className={({ isActive }) => `rounded-full px-4 py-2 text-sm font-medium transition-colors ${isActive ? 'bg-accent text-accent-foreground' : 'text-muted-foreground hover:text-foreground'}`}
                        >
                            {l.label}
                        </NavLink>
                    ))}
                </nav>
                <div className="ml-auto flex items-center gap-2 sm:ml-0">
                    <ThemeToggle />
                    <Link
                        to="/planner"
                        className="inline-flex h-11 items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:-translate-y-px active:scale-[0.98]"
                    >
                        Start free
                    </Link>
                </div>
            </div>
        </header>
    );
}

export function Footer() {
    return (
        <footer className="mt-24 border-t border-border bg-secondary/50">
            <div className="mx-auto grid w-full max-w-[80rem] gap-8 px-5 py-12 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
                <div>
                    <p className="font-display text-lg font-semibold">Financial Freedom Planner AI</p>
                    <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                        Understand your money, eliminate debt, build wealth. An educational planning tool that runs entirely
                        in your browser — no banking login, no account, nothing stored unless you choose to save it.
                    </p>
                </div>
                <nav className="text-sm">
                    <p className="mb-3 text-xs uppercase tracking-[0.16em] text-muted-foreground">Product</p>
                    <ul className="space-y-2">
                        {links.map((l) => (
                            <li key={l.to}><Link className="text-muted-foreground hover:text-foreground" to={l.to}>{l.label}</Link></li>
                        ))}
                        <li><Link className="text-muted-foreground hover:text-foreground" to="/about#privacy">Privacy &amp; data</Link></li>
                    </ul>
                </nav>
                <div className="text-sm text-muted-foreground">
                    <p className="mb-3 text-xs uppercase tracking-[0.16em]">Important</p>
                    <p>
                        This is an educational tool and does not provide regulated financial advice. Balances, interest rates
                        and projections are estimates for illustration only.
                    </p>
                </div>
            </div>
            <div className="border-t border-border px-5 py-5 text-center text-xs text-muted-foreground sm:px-8">
                © {new Date().getFullYear()} Financial Freedom Planner AI · Runs client-side over HTTPS · GDPR conscious by design
            </div>
        </footer>
    );
}
