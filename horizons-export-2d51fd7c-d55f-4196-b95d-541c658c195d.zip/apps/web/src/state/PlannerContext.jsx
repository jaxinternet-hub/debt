import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
    detectDebts, detectRecurring, healthScore, projectSavings,
    recommendations, scoreDebts, simulateMinimums, simulatePayoff, summarise,
} from '@/lib/finance';

const PlannerContext = createContext(null);
const SAVE_KEY = 'ffp.session.v1';

const DEFAULT_GOALS = [
    { id: 'g-emergency', name: 'Emergency Fund', target: 3000, saved: 250, monthly: 100 },
];

export function PlannerProvider({ children }) {
    const [transactions, setTransactions] = useState([]);
    const [sourceLabel, setSourceLabel] = useState('');
    const [method, setMethod] = useState('snowball');
    const [extra, setExtra] = useState(0);
    const [rate, setRate] = useState(5);
    const [goals, setGoals] = useState(DEFAULT_GOALS);
    const [debtOverrides, setDebtOverrides] = useState({});
    const [whatIf, setWhatIf] = useState({ income: 0, spendingCut: 0, extraDebt: 0, cancelSubs: 0 });
    const [notifications, setNotifications] = useState([]);
    const [savedAt, setSavedAt] = useState(null);

    const notify = useCallback((title, detail, tone = 'info') => {
        setNotifications((prev) => [{ id: `${Date.now()}-${Math.random()}`, title, detail, tone, at: new Date().toISOString() }, ...prev].slice(0, 12));
    }, []);

    const loadTransactions = useCallback((txs, label) => {
        setTransactions(txs);
        setSourceLabel(label || '');
        setDebtOverrides({});
    }, []);

    const recurring = useMemo(() => (transactions.length ? detectRecurring(transactions) : []), [transactions]);
    const summary = useMemo(() => (transactions.length ? summarise(transactions) : null), [transactions]);

    const debts = useMemo(() => {
        if (!transactions.length) return [];
        const base = detectDebts(transactions, recurring);
        const merged = base.map((d) => ({ ...d, ...(debtOverrides[d.id] || {}) }));
        return scoreDebts(merged);
    }, [transactions, recurring, debtOverrides]);

    const adjusted = useMemo(() => {
        if (!summary) return null;
        return {
            ...summary,
            monthlyIncome: summary.monthlyIncome + whatIf.income,
            monthlySpending: Math.max(0, summary.monthlySpending - whatIf.spendingCut - whatIf.cancelSubs),
            disposable: summary.disposable + whatIf.income + whatIf.spendingCut + whatIf.cancelSubs,
        };
    }, [summary, whatIf]);

    const totalExtra = extra + whatIf.extraDebt + whatIf.cancelSubs;

    const plan = useMemo(() => {
        const p = simulatePayoff(debts, method, totalExtra);
        return { ...p, method, extra: totalExtra };
    }, [debts, method, totalExtra]);

    const baseline = useMemo(() => simulateMinimums(debts), [debts]);

    const freedUp = useMemo(
        () => debts.reduce((s, d) => s + d.monthlyPayment, 0) + totalExtra,
        [debts, totalExtra],
    );

    const savingsMonthly = (adjusted?.savingsPayments || 0) + freedUp;
    const savings = useMemo(() => projectSavings(savingsMonthly, rate), [savingsMonthly, rate]);
    const health = useMemo(() => (adjusted ? healthScore(adjusted, debts) : null), [adjusted, debts]);
    const recs = useMemo(() => (adjusted ? recommendations(adjusted, recurring, debts) : []), [adjusted, recurring, debts]);

    const updateDebt = useCallback((id, patch) => {
        setDebtOverrides((prev) => ({ ...prev, [id]: { ...(prev[id] || {}), ...patch } }));
    }, []);

    const saveSession = useCallback(() => {
        const payload = { transactions, sourceLabel, method, extra, rate, goals, debtOverrides, savedAt: new Date().toISOString() };
        window.localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
        setSavedAt(payload.savedAt);
        notify('Session saved to this device', 'Stored in this browser only. Clear it any time from the privacy panel.', 'success');
    }, [transactions, sourceLabel, method, extra, rate, goals, debtOverrides, notify]);

    const restoreSession = useCallback(() => {
        try {
            const raw = window.localStorage.getItem(SAVE_KEY);
            if (!raw) return false;
            const p = JSON.parse(raw);
            setTransactions(p.transactions || []);
            setSourceLabel(p.sourceLabel || 'Saved session');
            setMethod(p.method || 'snowball');
            setExtra(p.extra || 0);
            setRate(p.rate ?? 5);
            setGoals(p.goals || DEFAULT_GOALS);
            setDebtOverrides(p.debtOverrides || {});
            setSavedAt(p.savedAt || null);
            return true;
        } catch { return false; }
    }, []);

    const clearEverything = useCallback(() => {
        window.localStorage.removeItem(SAVE_KEY);
        setTransactions([]); setSourceLabel(''); setDebtOverrides({});
        setGoals(DEFAULT_GOALS); setExtra(0); setWhatIf({ income: 0, spendingCut: 0, extraDebt: 0, cancelSubs: 0 });
        setSavedAt(null); setNotifications([]);
    }, []);

    const hasSaved = typeof window !== 'undefined' && !!window.localStorage.getItem(SAVE_KEY);

    /* Notifications derived from the analysis, generated once per data load. */
    useEffect(() => {
        if (!summary) return;
        const list = [];
        if (summary.disposable < 0) list.push(['Budget exceeded', `Spending is ${Math.abs(summary.disposable).toFixed(0)} GBP above income on average. Start with the fixed-cost wins in the optimiser.`, 'warn']);
        if (debts.length) list.push(['Debt plan ready', `${debts.length} credit agreements detected. Your rolling payoff plan is live below.`, 'info']);
        const subs = recurring.filter((r) => r.direction === 'debit' && r.amount < 30);
        if (subs.length >= 3) list.push(['Recurring payments detected', `${subs.length} small recurring payments found — worth a quick audit.`, 'info']);
        list.push(['Monthly review reminder', 'Come back at the start of next month and upload a fresh statement to see progress.', 'info']);
        setNotifications(list.map(([title, detail, tone], i) => ({ id: `auto-${i}-${Date.now()}`, title, detail, tone, at: new Date().toISOString() })));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [summary?.transactionCount, debts.length]);

    const value = {
        transactions, sourceLabel, loadTransactions,
        summary: adjusted, rawSummary: summary, recurring, debts, updateDebt,
        method, setMethod, extra, setExtra, rate, setRate,
        plan, baseline, freedUp, savings, savingsMonthly, health, recs,
        goals, setGoals, whatIf, setWhatIf,
        notifications, notify,
        saveSession, restoreSession, clearEverything, hasSaved, savedAt,
        hasData: transactions.length > 0,
    };

    return <PlannerContext.Provider value={value}>{children}</PlannerContext.Provider>;
}

export function usePlanner() {
    const ctx = useContext(PlannerContext);
    if (!ctx) throw new Error('usePlanner must be used inside PlannerProvider');
    return ctx;
}
